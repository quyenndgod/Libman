import requests

def main():
    url = input("Nhập URL: ").strip()
    r = requests.get(url, timeout=10)

    print("\n=== RESPONSE HEADERS ===")
    for k, v in r.headers.items():
        print(f"{k}: {v}")

    print("\n=== COOKIES ===")
    if r.cookies:
        for c in r.cookies:
            print(f"{c.name} = {c.value}")
    else:
        print("Không có cookie")

if __name__ == "__main__":
    main()
