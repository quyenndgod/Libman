import requests

SECURITY_HEADERS = {
    # Core security headers
    "Strict-Transport-Security": "HSTS",
    "Content-Security-Policy": "CSP",
    "X-Content-Type-Options": "MIME sniffing protection",
    "Access-Control-Allow-Origin": "CORS policy",

    # Cross-Origin isolation
    "Cross-Origin-Opener-Policy": "COOP",
    "Cross-Origin-Resource-Policy": "CORP",
    "Cross-Origin-Embedder-Policy": "COEP",

    # Privacy & data protection
    "Referrer-Policy": "Referrer control",
    "Cache-Control": "Cache control",
    "Clear-Site-Data": "Clear browser data",
    "Permissions-Policy": "Browser permissions",
}

COOKIE_FLAGS = ["HttpOnly", "Secure", "SameSite"]


def main():
    url = input("Nhập URL: ").strip()

    try:
        response = requests.get(url, timeout=10)

        print("\n=== MISSING SECURITY HEADERS ===")
        missing = False

        for header, desc in SECURITY_HEADERS.items():
            if header not in response.headers:
                print(f"- {header} : ({desc})")
                missing = True

        if not missing:
            print("Không thiếu security header nào.")

        print("\n=== COOKIE SECURITY FLAGS CHECK ===")
        set_cookies = response.raw.headers.get_all("Set-Cookie")

        if not set_cookies:
            print("- Không có Set-Cookie header")
        else:
            for sc in set_cookies:
                print(f"\nSet-Cookie: {sc}")
                for flag in COOKIE_FLAGS:
                    if flag.lower() not in sc.lower():
                        print(f"    Missing {flag}")
                    else:
                        print(f"{flag} present")

    except requests.exceptions.RequestException as e:
        print(f"Lỗi khi gửi request: {e}")


if __name__ == "__main__":
    main()
